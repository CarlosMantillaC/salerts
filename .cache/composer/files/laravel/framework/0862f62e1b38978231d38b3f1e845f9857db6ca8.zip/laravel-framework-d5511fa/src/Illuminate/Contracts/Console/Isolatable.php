<?php

namespace Illuminate\Contracts\Console;

interface Isolatable
{
    //
}
