<?php

declare(strict_types=1);

namespace Termwind\Components;

final class Dt extends Element
{
    protected static array $defaultStyles = ['block', 'font-bold'];
}
